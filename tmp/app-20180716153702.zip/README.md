# Time Zone Converter

This App is used to find and schedule meeting at Ticket Requester and Assignee's suitable time.

### About:

* Requester's Clock is running at top
* Assignee's Clock is running at bottom
* You can select any of the requester or Assigner's time to see other's time in his input boxes
* you can enable or disable colors using the checkbox at bottom
* Currently their are two colors(if enabled):
green is used to show it is under working hours
red shows out of working hour
* Click on Schedule button to select the time
* Edit comment if required 
* Click on submit button to notify requester

### Stack:

* ZAF (Zendesk App Framwork)
* JavaScript / JQuery
* CSS
* HTML

### Core Contributors:

* [Jagdish Singh](https://github.com/JDchauhan)

Please submit bug reports to [https://github.com/hexerve/time-zone-converter](https://github.com/hexerve/time-zone-converter). Pull requests are welcome.